"""Descoberta ao vivo da demonstração, executada no navegador com Pyodide.

Roda o código do produto (``observable_atlas``) sem alterações sobre os vídeos
sintéticos que a pessoa selecionou. Só a VLM fica de fora: as respostas
roteirizadas e os embeddings BGE de cada frase vêm de um cache gerado por
``demo/build_demo.py``. Duas substituições, necessárias porque estas
bibliotecas não existem no Pyodide:

* ``hdbscan`` → ``sklearn.cluster.HDBSCAN`` (mesmos parâmetros; outra implementação
  do mesmo algoritmo, que pode diferir em casos de empate);
* ``umap`` → interpolação no layout UMAP pré-calculado do corpus completo
  (vizinhos mais próximos por cosseno). Só afeta as posições exibidas.

Também roda em CPython, o que permite testá-lo fora do navegador.
"""
from __future__ import annotations

import base64
import json
from pathlib import Path
import sys
import time
import types

import numpy as np

EMB = INDEX = LAYOUT = VIDEOS = None


def _install_shims() -> None:
    from sklearn.cluster import HDBSCAN as SkHDBSCAN

    class HDBSCAN:
        def __init__(self, metric="euclidean", min_cluster_size=5, min_samples=None, cluster_selection_method="eom"):
            self.model = SkHDBSCAN(metric=metric, min_cluster_size=min_cluster_size, min_samples=min_samples,
                                   cluster_selection_method=cluster_selection_method)

        def fit_predict(self, X):
            return self.model.fit_predict(X)

    class UMAP:
        def __init__(self, **_):
            pass

        def fit_transform(self, X):
            sims = np.asarray(X, dtype=np.float32) @ EMB.T
            nearest = np.argsort(-sims, axis=1)[:, :6]
            weights = np.maximum(np.take_along_axis(sims, nearest, 1), 0) ** 8 + 1e-9
            return (LAYOUT[nearest] * weights[..., None]).sum(1) / weights.sum(1, keepdims=True)

    sys.modules["hdbscan"] = types.SimpleNamespace(HDBSCAN=HDBSCAN)
    sys.modules["umap"] = types.SimpleNamespace(UMAP=UMAP)


def load(corpus_json: str) -> int:
    """Recebe o conteúdo de data/corpus.json e prepara o cache. Devolve o número de vídeos."""
    global EMB, INDEX, LAYOUT, VIDEOS
    corpus = json.loads(corpus_json)
    EMB = np.frombuffer(base64.b64decode(corpus["emb"]), dtype=np.float16).astype(np.float32).reshape(-1, corpus["dim"])
    EMB /= np.linalg.norm(EMB, axis=1, keepdims=True)
    INDEX = {text: i for i, text in enumerate(corpus["texts"])}
    LAYOUT = np.asarray(corpus["layout"], dtype=np.float32).reshape(-1, 3)
    VIDEOS = {v["v"]: v for v in corpus["videos"]}
    _install_shims()
    import observable_atlas.clustering as clustering

    def cached_encode(texts, *_args, **_kwargs):
        missing = [t for t in texts if t not in INDEX]
        if missing:
            raise KeyError(f"embedding não está no cache: {missing[0]!r}")
        return EMB[[INDEX[t] for t in texts]]

    clustering.encode = cached_encode
    return len(VIDEOS)


def run(request_json: str, emit=None) -> str:
    """``{"videos": [...nomes], "min_cluster_size": 8}`` → JSON do atlas (mesmo formato de atlas-data.js)."""
    from observable_atlas.atlas import atlas_payload
    from observable_atlas.config import DiscoveryConfig
    from observable_atlas.contract import ContractError, parse_response
    from observable_atlas.corpus import build_corpus
    from observable_atlas.discovery import discover

    request = json.loads(request_json)
    timings, started = {}, time.perf_counter()

    def say(step, **info):
        if emit:
            emit(json.dumps({"step": step, "t": round(time.perf_counter() - started, 2), **info}))

    records, invalid = [], 0
    for name in request["videos"]:
        item = VIDEOS[name]
        window = {"window_index": 0, "status": "invalid", "attempts": [{"attempt": 1, "raw_response": item["r"]}]}
        try:
            parsed = parse_response(item["r"])  # o mesmo contrato do produto
            window.update(status="valid", anomaly=parsed.anomaly, evidence=parsed.evidence, parse_status=parsed.parse_status)
        except ContractError as exc:
            window["error"] = str(exc)
            invalid += 1
        records.append({"video_id": Path(name).stem, "source_name": name, "video_sha256": name, "model": "Simulated VLM",
                        "sampling": "uniform16", "status": "complete" if window["status"] == "valid" else "failed",
                        "anomaly": window.get("anomaly"), "windows": [window]})
    say("validated", videos=len(records), invalid=invalid)
    corpus = build_corpus(records)
    timings["validation_seconds"] = round(time.perf_counter() - started, 2)
    config = DiscoveryConfig(min_cluster_size=int(request.get("min_cluster_size", 8)))
    t0 = time.perf_counter()
    taxonomy = discover(corpus, config, Path("/tmp/atlas-demo-run"),
                        progress=lambda event: say(event.get("step", "discovery"), **{k: v for k, v in event.items() if k not in {"stage", "step"}}))
    timings["discovery_seconds"] = round(time.perf_counter() - t0, 2)
    taxonomy["parameters"]["projection"] = {key: "cached UMAP layout of the full synthetic corpus (display only)"
                                            for key in taxonomy["parameters"]["projection"]}
    taxonomy["parameters"]["hdbscan"]["implementation"] = "scikit-learn HDBSCAN (browser demo)"
    taxonomy["software"] = {"runtime": "Pyodide " + sys.version.split()[0]}
    run_meta = {"name": request.get("name") or "Synthetic demonstration corpus",
                "config": {"extraction": {"sampling": "uniform16"}},
                "extraction": {"backend": {"backend": "simulated", "model_name": "Simulated VLM", "frame_size": [448, 448],
                                           "max_images": 16}},
                "timings": timings}
    payload = atlas_payload(taxonomy, run_meta, simulated=True)
    say("done", **taxonomy["counts"])
    return json.dumps(payload, separators=(",", ":"))
