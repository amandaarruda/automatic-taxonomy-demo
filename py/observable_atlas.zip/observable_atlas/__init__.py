"""Descoberta automática de taxonomia de evidências visuais e Observable Evidence Atlas."""

__version__ = "1.0.0"
