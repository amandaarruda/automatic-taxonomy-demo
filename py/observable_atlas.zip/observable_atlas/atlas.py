"""Etapa 6: empacota o Observable Evidence Atlas de uma execução.

Copia o visualizador estático (``observable_atlas/viewer``) para ``atlas/`` e
grava ``atlas/data/atlas-data.js`` com os dados da execução. O resultado abre
direto do disco (file://) e pode ser compartilhado como uma pasta ou um .zip.
"""
from __future__ import annotations

from importlib.resources import as_file, files
import json
import math
from pathlib import Path
import re
import shutil

SHAPES = 4  # círculo, losango, quadrado, triângulo


def _oklch(lightness: float, chroma: float, hue: float) -> str:
    a, b = chroma * math.cos(math.radians(hue)), chroma * math.sin(math.radians(hue))
    l_ = (lightness + .3963377774 * a + .2158037573 * b) ** 3
    m_ = (lightness - .1055613458 * a - .0638541728 * b) ** 3
    s_ = (lightness - .0894841775 * a - 1.291485548 * b) ** 3
    rgb = [4.0767416621 * l_ - 3.3077115913 * m_ + .2309699292 * s_,
           -1.2684380046 * l_ + 2.6097574011 * m_ - .3413193965 * s_,
           -.0041960863 * l_ - .7034186147 * m_ + 1.707614701 * s_]
    gamma = lambda v: 12.92 * v if v <= .0031308 else 1.055 * v ** (1 / 2.4) - .055
    return "#%02x%02x%02x" % tuple(max(0, min(255, round(gamma(max(0, v)) * 255))) for v in rgb)


def palette(count: int, offset: float = 25) -> list[str]:
    """Mesma paleta do atlas original: matizes em ângulo áureo e luminosidade alternada."""
    return [_oklch([.78, .70, .84, .64][i % 4], .15 if i % 4 != 2 else .11, (i * 137.508 + offset) % 360)
            for i in range(count)]


def align(points: list) -> list:
    """Gira a projeção para os eixos principais: maior variância na horizontal (x), menor na vertical (y).

    Só muda a orientação de exibição; distâncias entre pontos são preservadas.
    """
    import numpy as np

    data = np.asarray(points, dtype=float).reshape(-1, 3)
    if len(data) < 3:
        return data.round(4).tolist()
    centered = data - data.mean(axis=0)
    _, _, axes = np.linalg.svd(centered, full_matrices=False)
    rotated = centered @ axes.T  # colunas: PC1, PC2, PC3
    return rotated[:, [0, 2, 1]].round(4).tolist()


def model_key(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "model"


def atlas_payload(taxonomy: dict, run: dict | None = None, simulated: bool = False) -> dict:
    run = run or {}
    models = taxonomy["models"]
    keys = {name: model_key(name) for name in models}
    families = []
    for family, color in zip(taxonomy["families"], palette(len(taxonomy["families"]))):
        comp = family["composition"]
        families.append({"id": family["id"], "code": family["code"], "name": family["name"],
                         "topics": [t["term"] for t in family["topics"]], "rep": family["representative"],
                         "color": color, "keys": [], "pct": round(100 * (comp["share"] or 0), 1),
                         "cat": comp["category"]})
    orphans = [c for c in taxonomy["clusters"] if not c["family"]]
    if orphans:
        families.append({"id": len(families) + 1, "code": "—", "name": "Not grouped", "topics": [],
                         "rep": "Clusters that did not enter the second grouping stage.", "color": "#8a8f98",
                         "keys": [], "pct": None, "cat": None, "unassigned": True})
    clusters = {}
    for cluster, color in zip(taxonomy["clusters"], palette(len(taxonomy["clusters"]), offset=200)):
        family_id = cluster["family"] or families[-1]["id"]
        comp = cluster["composition"]
        clusters[cluster["key"]] = {
            "model": keys[cluster["model"]], "id": cluster["hdbscan_label"], "fam": family_id,
            "pct": round(100 * (comp["share"] or 0), 1), "cat": comp["category"] or "Neutral",
            "n": cluster["statements"], "occ": cluster["occurrences"], "vids": cluster["videos"],
            "name": cluster["name"], "topics": [t["term"] for t in cluster["topics"]],
            "rep": cluster["representative"], "color": color, "flags": cluster["flags"],
            "excluded": cluster["excluded_from_hierarchy"]}
        families[family_id - 1]["keys"].append(cluster["key"])
    for family in families:
        family["keys"].sort(key=lambda k: (-clusters[k]["n"], k))

    video_index = {}
    videos = []
    for video in taxonomy["videos"]:
        index_key = (video["model"], video["video_id"])
        video_index[index_key] = len(videos)
        videos.append({"id": video["video_id"], "name": video["source_name"], "model": keys[video["model"]],
                       "status": video["status"], "anomaly": video["anomaly"],
                       "dur": video.get("duration_seconds"), "windows": video.get("windows"),
                       **({"error": video["error"]} if video.get("error") else {})})
    model_data = {}
    for name in models:
        cluster_keys = sorted([c["key"] for c in taxonomy["clusters"] if c["model"] == name],
                              key=lambda k: clusters[k]["id"])
        position = {k: i for i, k in enumerate(cluster_keys)}
        rows = [s for s in taxonomy["statements"] if s["model"] == name]
        model_data[keys[name]] = {
            "label": name, "keys": cluster_keys,
            "xyz": [v for point in align([row["xyz"] or [0, 0, 0] for row in rows]) for v in point],
            "cl": [position[row["cluster"]] if row["cluster"] else -1 for row in rows],
            "ev": [row["text"] for row in rows],
            # Proveniência: [índice do vídeo, janela, decisão da VLM] de cada ocorrência.
            "src": [[[video_index[(name, o["video_id"])], o["window_index"], o["anomaly"]]
                     for o in row["occurrences"]] for row in rows]}
    centroid_points = align([c["centroid_xyz"] for c in taxonomy["clusters"]])
    centroids = [{"k": c["key"], "f": clusters[c["key"]]["fam"], "p": point}
                 for c, point in zip(taxonomy["clusters"], centroid_points)]
    extraction = run.get("extraction") or {}
    meta = {"title": run.get("name") or "Video corpus", "status": taxonomy["status"], "simulated": simulated,
            "created": taxonomy["created_at_utc"], "composition": taxonomy["composition_source"],
            "models": [{"key": keys[n], "label": n, "shape": i % SHAPES} for i, n in enumerate(models)],
            "counts": taxonomy["counts"], "quality": taxonomy["corpus_quality"],
            "diagnostics": taxonomy["diagnostics"], "hierarchy": taxonomy["hierarchy"],
            "parameters": {k: v for k, v in taxonomy["parameters"].items() if k != "hierarchy"},
            "sampling": (run.get("config") or {}).get("extraction", {}).get("sampling"),
            "backend": {k: v for k, v in (extraction.get("backend") or {}).items()
                        if k in {"backend", "model", "model_name", "revision", "precision", "device", "gpu",
                                 "max_images", "frame_size"}},
            "timings": run.get("timings"), "software": taxonomy.get("software")}
    return {"meta": meta, "legend": taxonomy["categories"], "families": families, "clusters": clusters,
            "models": model_data, "centroids": centroids, "videos": videos}


def viewer_source():
    return files("observable_atlas").joinpath("viewer")


def build_atlas(taxonomy: dict, destination: Path, run: dict | None = None, simulated: bool = False) -> Path:
    if destination.exists():
        shutil.rmtree(destination)
    with as_file(viewer_source()) as source:
        shutil.copytree(source, destination, ignore=shutil.ignore_patterns("__pycache__", "data"))
    (destination / "data").mkdir(exist_ok=True)
    payload = atlas_payload(taxonomy, run, simulated)
    (destination / "data" / "atlas-data.js").write_text(
        "window.ATLAS=" + json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + ";\n", encoding="utf-8")
    return destination / "index.html"
