"""Etapa 3: embeddings BGE e primeiro agrupamento (HDBSCAN por VLM).

Segue a seção 3.3 do artigo: ``BAAI/bge-small-en-v1.5`` com vetores de 384
dimensões normalizados (L2) e HDBSCAN com distância euclidiana, aplicado
separadamente a cada VLM. Frases que o HDBSCAN não atribui a nenhum grupo
ficam como ruído e continuam visíveis no atlas.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import re

import numpy as np

from .corpus import Corpus, Statement

# Termos usados nas sinalizações automáticas. No artigo, revisores rejeitaram
# grupos dominados por aparência (sobretudo cor), qualidade de imagem ou
# frases vagas. Aqui isso vira uma marcação auditável, não uma decisão humana.
FLAG_LEXICON = {
    "appearance": r"\b(red|blue|green|yellow|black|white|gr[ae]y|orange|purple|pink|brown|beige|dark-colored|"
                  r"light-colored|shirt|t-shirt|jacket|hoodie|coat|pants|jeans|shorts|dress|skirt|hat|cap|"
                  r"helmet|uniform|clothing|clothes|wearing|outfit|sweater|vest)\b",
    "image_quality": r"\b(blurr?y|blurred|grainy|pixelated|low[- ]resolution|low[- ]quality|low visibility|"
                     r"poor visibility|out of focus|distorted|overexposed|underexposed|static image|"
                     r"camera angle|camera view|footage quality)\b",
    "generic": r"\b(no (visible )?(anomal\w*|unusual|abnormal)|nothing unusual|normal activity|ordinary activity|"
               r"routine activity|no signs? of)\b",
}
FLAG_THRESHOLD = 0.5


@dataclass(eq=False)
class Cluster:
    key: str
    model: str
    label: int
    statement_ids: list[str]
    centroid: np.ndarray
    medoid_id: str
    flags: list[str] = field(default_factory=list)
    flag_shares: dict = field(default_factory=dict)


def encode(texts: list[str], model_name: str, revision: str | None, local_files_only: bool) -> np.ndarray:
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise RuntimeError("instale as dependências da descoberta: pip install -e '.[discovery]'") from exc
    try:
        encoder = SentenceTransformer(model_name, revision=revision, local_files_only=local_files_only)
    except OSError as exc:
        raise RuntimeError(f"não foi possível carregar o modelo de embeddings {model_name}: {exc}. "
                           "Prepare o cache (docs/INSTALACAO.md) ou desligue local_files_only.") from exc
    vectors = encoder.encode(texts, normalize_embeddings=True, convert_to_numpy=True,
                             show_progress_bar=False, batch_size=64)
    vectors = np.asarray(vectors, dtype=np.float32)
    return vectors / np.maximum(np.linalg.norm(vectors, axis=1, keepdims=True), 1e-12)


def suitability_flags(texts: list[str]) -> tuple[list[str], dict]:
    shares = {}
    for name, pattern in FLAG_LEXICON.items():
        regex = re.compile(pattern, re.IGNORECASE)
        shares[name] = round(sum(bool(regex.search(text)) for text in texts) / max(len(texts), 1), 3)
    return sorted(name for name, share in shares.items() if share >= FLAG_THRESHOLD), shares


def cluster_model(statements: list[Statement], vectors: np.ndarray, min_cluster_size: int,
                  min_samples: int) -> tuple[np.ndarray, list[Cluster]]:
    """Devolve os rótulos HDBSCAN (-1 = ruído) e os grupos de uma VLM."""
    if len(statements) < max(min_cluster_size, 2):
        return np.full(len(statements), -1), []
    import hdbscan

    labels = hdbscan.HDBSCAN(metric="euclidean", min_cluster_size=min_cluster_size, min_samples=min_samples,
                             cluster_selection_method="eom").fit_predict(vectors.astype(np.float64))
    model = statements[0].model
    clusters = []
    for label in sorted(set(int(value) for value in labels) - {-1}):
        members = np.flatnonzero(labels == label)
        centroid = vectors[members].mean(axis=0)
        centroid /= max(float(np.linalg.norm(centroid)), 1e-12)
        # Medoide: a frase real mais próxima do centroide. É a evidência representativa.
        medoid = members[int(np.argmax(vectors[members] @ centroid))]
        texts = [statements[i].text for i in members]
        flags, shares = suitability_flags(texts)
        clusters.append(Cluster(key=f"{model}::{label}", model=model, label=label,
                                statement_ids=[statements[i].statement_id for i in members],
                                centroid=centroid, medoid_id=statements[medoid].statement_id,
                                flags=flags, flag_shares=shares))
    return labels, clusters


def first_stage(corpus: Corpus, model_name: str, revision: str | None, local_files_only: bool,
                min_cluster_size: int, min_samples: int) -> tuple[dict[str, np.ndarray], dict[str, int], list[Cluster]]:
    vectors_by_id: dict[str, np.ndarray] = {}
    label_by_id: dict[str, int] = {}
    clusters: list[Cluster] = []
    for model in corpus.models:
        subset = corpus.by_model(model)
        vectors = encode([item.text for item in subset], model_name, revision, local_files_only)
        labels, found = cluster_model(subset, vectors, min_cluster_size, min_samples)
        for statement, vector, label in zip(subset, vectors, labels):
            vectors_by_id[statement.statement_id] = vector
            label_by_id[statement.statement_id] = int(label)
        clusters.extend(found)
    return vectors_by_id, label_by_id, clusters
