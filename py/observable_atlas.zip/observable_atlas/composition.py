"""Composição dos grupos por vídeos anômalos (seção 3.5 do artigo).

Para cada grupo, p_a = N_a / (N_a + N_n), contando vídeos únicos. O artigo usa
os rótulos do conjunto de dados. Aqui há duas fontes possíveis:

* ``reference``: rótulos fornecidos pelo cliente num CSV (video,label). Os
  rótulos nunca são enviados à VLM;
* ``prediction`` (padrão quando não há CSV): a decisão da própria VLM. Um vídeo
  conta como anômalo para o grupo se alguma ocorrência dele no grupo veio de
  uma janela com anomaly=1. Isso descreve o que a VLM decidiu, não a verdade.
"""
from __future__ import annotations

import csv
from pathlib import Path

CATEGORIES = [
    {"cat": "Anomalous", "rule": "100", "color": "#C00000", "text": "all supporting videos are anomalous"},
    {"cat": "Predominantly Anomalous", "rule": "> 50 and < 100", "color": "#F4CCCC",
     "text": "more than half of the supporting videos are anomalous"},
    {"cat": "Neutral", "rule": "50", "color": "#D9E1F2", "text": "equal shares of anomalous and normal videos"},
    {"cat": "Predominantly Normal", "rule": "> 0 and < 50", "color": "#D9EAD3",
     "text": "less than half, but not zero, of the supporting videos are anomalous"},
    {"cat": "Normal", "rule": "0", "color": "#70AD47", "text": "no anomalous video among the supporting videos"},
]


def category(share: float) -> str:
    if share >= 1:
        return "Anomalous"
    if share > 0.5:
        return "Predominantly Anomalous"
    if share == 0.5:
        return "Neutral"
    if share > 0:
        return "Predominantly Normal"
    return "Normal"


def load_reference_labels(path: Path) -> dict[str, int]:
    """CSV com cabeçalho ``video,label``. ``video`` é o nome do arquivo ou seu nome sem extensão."""
    labels = {}
    with Path(path).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        if not reader.fieldnames or not {"video", "label"} <= set(reader.fieldnames):
            raise ValueError(f"{path}: o CSV precisa das colunas video e label")
        for number, row in enumerate(reader, 2):
            value = (row["label"] or "").strip().lower()
            if value in {"1", "anomalous", "anomaly", "abnormal"}:
                label = 1
            elif value in {"0", "normal"}:
                label = 0
            else:
                raise ValueError(f"{path}:{number}: label deve ser 0/1 ou normal/anomalous; recebido {row['label']!r}")
            labels[Path(row["video"].strip()).stem] = label
    return labels


def composition(occurrences: list, video_labels: dict[str, int] | None) -> dict:
    """``occurrences``: ocorrências (com video_id e anomaly) de um grupo."""
    if video_labels is not None:
        videos = {item.video_id for item in occurrences if item.video_id in video_labels}
        anomalous = {video for video in videos if video_labels[video] == 1}
    else:
        videos = {item.video_id for item in occurrences}
        anomalous = {item.video_id for item in occurrences if item.anomaly == 1}
    if not videos:
        return {"share": None, "category": None, "videos": 0, "anomalous_videos": 0}
    share = len(anomalous) / len(videos)
    return {"share": round(share, 4), "category": category(share), "videos": len(videos),
            "anomalous_videos": len(anomalous)}
