"""Configuração de uma execução.

Os valores padrão reproduzem o experimento da pesquisa. Um arquivo TOML pode
substituir qualquer campo; veja ``configs/`` e docs/CONFIGURACAO.md.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
import sys

if sys.version_info >= (3, 11):
    import tomllib
else:  # pragma: no cover
    import tomli as tomllib

from .sampling import SAMPLING_MODES, parse_frame_size


@dataclass
class ExtractionConfig:
    sampling: str = "uniform16"
    # Frames redimensionados para 448×448, como o processador do InternVL fez na pesquisa.
    frame_size: str = "448x448"
    # Limite de imagens por chamada; no modo 1 fps define o tamanho da janela.
    window_size: int = 16
    max_new_tokens: int = 384
    # Uma única nova tentativa, com mais tokens, quando a resposta foi cortada.
    retry_max_new_tokens: int = 768
    # "strict" exige JSON puro; "embedded" aceita o objeto dentro de texto (marcado).
    json_recovery: str = "strict"
    keep_frames: bool = False

    def validate(self) -> None:
        if self.sampling not in SAMPLING_MODES:
            raise ValueError(f"extraction.sampling deve ser um de {SAMPLING_MODES}")
        parse_frame_size(self.frame_size)
        if not 1 <= self.window_size <= 64:
            raise ValueError("extraction.window_size deve ficar entre 1 e 64")
        if self.max_new_tokens < 16 or self.retry_max_new_tokens < self.max_new_tokens:
            raise ValueError("retry_max_new_tokens deve ser maior ou igual a max_new_tokens (mínimo 16)")
        if self.json_recovery not in {"strict", "embedded"}:
            raise ValueError("extraction.json_recovery deve ser 'strict' ou 'embedded'")


@dataclass
class DiscoveryConfig:
    embedding_model: str = "BAAI/bge-small-en-v1.5"
    embedding_revision: str | None = "5c38ec7c405ec4b44b94cc5a9bb96e735b38267a"
    min_cluster_size: int = 8
    min_samples: int = 1
    seed: int = 2027
    bootstrap_replicates: int = 50
    bootstrap_fraction: float = 0.8
    # Sinalizações automáticas que tiram um grupo da segunda etapa.
    # Vazio = todos os grupos seguem (padrão). Ex.: ["appearance"].
    exclude_flags: list[str] = field(default_factory=list)
    # CSV opcional com rótulos de referência (colunas: video,label). Nunca vai para a VLM.
    reference_labels: str | None = None
    local_files_only: bool = False

    def validate(self) -> None:
        if self.min_cluster_size < 2:
            raise ValueError("discovery.min_cluster_size deve ser no mínimo 2")
        if self.min_samples < 1:
            raise ValueError("discovery.min_samples deve ser no mínimo 1")
        if not 0.3 <= self.bootstrap_fraction < 1:
            raise ValueError("discovery.bootstrap_fraction deve ficar entre 0.3 e 1")
        if self.bootstrap_replicates < 1:
            raise ValueError("discovery.bootstrap_replicates deve ser positivo")
        unknown = set(self.exclude_flags) - {"appearance", "image_quality", "generic"}
        if unknown:
            raise ValueError(f"discovery.exclude_flags desconhecidas: {sorted(unknown)}")


@dataclass
class RunConfig:
    name: str = "Video corpus"
    extraction: ExtractionConfig = field(default_factory=ExtractionConfig)
    discovery: DiscoveryConfig = field(default_factory=DiscoveryConfig)
    vlm: dict = field(default_factory=lambda: {"backend": "internvl-hf"})

    def validate(self) -> "RunConfig":
        self.extraction.validate()
        self.discovery.validate()
        if "backend" not in self.vlm:
            raise ValueError("a seção [vlm] precisa do campo backend")
        return self

    def to_dict(self) -> dict:
        return asdict(self)


def _merge(target, values: dict, section: str):
    allowed = {item.name for item in fields(target)}
    for key, value in values.items():
        if key not in allowed:
            raise ValueError(f"campo desconhecido em [{section}]: {key}")
        setattr(target, key, value)


def config_from_dict(data: dict) -> RunConfig:
    config = RunConfig()
    for key, value in data.items():
        if key == "extraction":
            _merge(config.extraction, value, key)
        elif key == "discovery":
            _merge(config.discovery, value, key)
        elif key == "vlm":
            config.vlm = dict(value)
        elif key == "name":
            config.name = str(value)
        else:
            raise ValueError(f"seção desconhecida na configuração: {key}")
    return config.validate()


def load_config(path: Path | None) -> RunConfig:
    if path is None:
        return RunConfig().validate()
    with Path(path).open("rb") as stream:
        return config_from_dict(tomllib.load(stream))
