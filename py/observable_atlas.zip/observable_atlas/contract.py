"""Prompt e validação do contrato de saída da VLM.

A validação é estrutural: verifica o JSON pedido pelo prompt, não se a frase
corresponde ao vídeo. Nenhuma resposta é corrigida ou completada; uma resposta
inválida gera ``ContractError`` com o motivo.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
from importlib.resources import files
import json
import re

# SHA-256 dos bytes de prompt.txt. É o mesmo prompt N2.1 da pesquisa; o teste
# de contrato falha se alguém editar o arquivo.
PROMPT_SHA256 = "e5ad994f6b1b99000ba3e2a2f05a4b33955e5f98095f064237003f51cd64edff"
MAX_EVIDENCE = 3
MAX_WORDS = 15


def prompt() -> str:
    return files("observable_atlas").joinpath("prompt.txt").read_text(encoding="utf-8")


def prompt_sha256() -> str:
    return hashlib.sha256(prompt().encode("utf-8")).hexdigest()


class ContractError(ValueError):
    """A resposta da VLM não segue o formato exigido pelo prompt."""

    def __init__(self, message: str, *, truncated: bool = False):
        super().__init__(message)
        self.truncated = truncated


@dataclass(frozen=True)
class ParsedResponse:
    anomaly: int
    evidence: list[str]
    # "strict": a resposta inteira é o objeto JSON.
    # "embedded": o objeto foi lido de dentro de um texto maior (só com recovery="embedded").
    parse_status: str


def _no_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ContractError(f"campo JSON repetido: {key}")
        result[key] = value
    return result


def _reject_constant(value):
    raise ContractError(f"constante JSON não permitida: {value}")


def _loads(text: str):
    return json.loads(text, object_pairs_hook=_no_duplicate_keys, parse_constant=_reject_constant)


def validate_payload(data) -> ParsedResponse:
    if not isinstance(data, dict):
        raise ContractError("a resposta deve ser um objeto JSON")
    if set(data) != {"anomaly", "evidence"}:
        raise ContractError(f"os campos devem ser exatamente anomaly e evidence; recebido: {sorted(data)}")
    if type(data["anomaly"]) is not int or data["anomaly"] not in (0, 1):
        raise ContractError("anomaly deve ser o inteiro 0 ou 1")
    evidence = data["evidence"]
    if not isinstance(evidence, list) or not 1 <= len(evidence) <= MAX_EVIDENCE:
        raise ContractError(f"evidence deve ser uma lista com 1 a {MAX_EVIDENCE} frases")
    for index, item in enumerate(evidence):
        if not isinstance(item, str) or not item.strip():
            raise ContractError(f"a evidência {index + 1} deve ser um texto não vazio")
        words = len(item.split())
        if words > MAX_WORDS:
            raise ContractError(f"a evidência {index + 1} tem {words} palavras (máximo {MAX_WORDS})")
    return ParsedResponse(data["anomaly"], list(evidence), "strict")


def _looks_truncated(text: str) -> bool:
    stripped = text.strip()
    return stripped.count("{") > stripped.count("}") or stripped.count('"') % 2 == 1


def _first_object(text: str):
    decoder = json.JSONDecoder(object_pairs_hook=_no_duplicate_keys, parse_constant=_reject_constant)
    for match in re.finditer(r"\{", text):
        try:
            value, _ = decoder.raw_decode(text[match.start():])
        except json.JSONDecodeError:
            continue
        return value
    return None


def parse_response(raw: str, recovery: str = "strict") -> ParsedResponse:
    """Valida a resposta bruta.

    ``recovery="strict"`` (padrão) exige que a resposta inteira seja o objeto.
    ``recovery="embedded"`` aceita o primeiro objeto JSON contido num texto
    maior, como na pesquisa original; o objeto não é alterado e o resultado é
    marcado com ``parse_status="embedded"``.
    """
    if recovery not in {"strict", "embedded"}:
        raise ValueError("recovery deve ser 'strict' ou 'embedded'")
    if not isinstance(raw, str):
        raise ContractError("o modelo não devolveu texto")
    try:
        return validate_payload(_loads(raw))
    except json.JSONDecodeError as exc:
        strict_error = ContractError(f"JSON inválido: {exc.msg}", truncated=_looks_truncated(raw))
    if recovery == "embedded":
        value = _first_object(raw)
        if value is not None:
            parsed = validate_payload(value)
            return ParsedResponse(parsed.anomaly, parsed.evidence, "embedded")
    raise strict_error
