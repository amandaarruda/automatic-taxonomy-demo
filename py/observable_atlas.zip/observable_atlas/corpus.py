"""Etapa 2: respostas validadas → corpus de evidências com proveniência.

Como no artigo (seção 3.3): cada frase não vazia é uma evidência; o único
pré-processamento é remover espaços nas pontas e colapsar espaços repetidos; a
deduplicação é por texto normalizado exato, separadamente para cada VLM. Cada
frase única mantém a lista das ocorrências (vídeo, janela, ordem, decisão).
"""
from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
from pathlib import Path
import re


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip())


def stable_id(prefix: str, *parts: str) -> str:
    return prefix + "-" + hashlib.sha256("\x00".join(parts).encode("utf-8")).hexdigest()[:12]


@dataclass
class Occurrence:
    occurrence_id: str
    statement_id: str
    video_id: str
    window_index: int
    evidence_order: int
    anomaly: int
    start_seconds: float | None
    end_seconds: float | None
    parse_status: str
    original_text: str


@dataclass
class Statement:
    statement_id: str
    model: str
    text: str
    occurrences: list[Occurrence] = field(default_factory=list)

    @property
    def video_ids(self) -> list[str]:
        return sorted({item.video_id for item in self.occurrences})


@dataclass
class Corpus:
    statements: list[Statement]
    videos: list[dict]
    quality: dict

    @property
    def models(self) -> list[str]:
        return sorted({statement.model for statement in self.statements})

    def by_model(self, model: str) -> list[Statement]:
        return [statement for statement in self.statements if statement.model == model]


def read_video_records(path: Path) -> list[dict]:
    """Lê ``videos.jsonl``; quando um vídeo aparece mais de uma vez (retomada), vale a última linha."""
    latest: dict[tuple, dict] = {}
    bad_lines = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            bad_lines.append(number)
            continue
        if not isinstance(row, dict) or not row.get("video_id") or not row.get("model"):
            bad_lines.append(number)
            continue
        latest[(row["model"], row.get("video_sha256") or row["video_id"])] = row
    if bad_lines:
        raise ValueError(f"{path}: linhas ilegíveis ou sem video_id/model: {bad_lines[:10]}")
    return list(latest.values())


def build_corpus(records: list[dict]) -> Corpus:
    statements: dict[tuple[str, str], Statement] = {}
    videos = []
    windows_valid = windows_invalid = 0
    parse_status = {"strict": 0, "embedded": 0}
    for row in records:
        video_windows = row.get("windows") or []
        videos.append({key: row.get(key) for key in (
            "video_id", "source_name", "model", "sampling", "status", "anomaly", "duration_seconds",
            "frame_count", "fps", "width", "height", "error")} | {"windows": len(video_windows)})
        for window in video_windows:
            if window.get("status") != "valid":
                windows_invalid += 1
                continue
            windows_valid += 1
            status = window.get("parse_status", "strict")
            parse_status[status] = parse_status.get(status, 0) + 1
            for order, original in enumerate(window.get("evidence", [])):
                text = normalize_text(original)
                if not text:
                    continue
                key = (row["model"], text)
                if key not in statements:
                    statements[key] = Statement(stable_id("ev", *key), row["model"], text)
                statement = statements[key]
                statement.occurrences.append(Occurrence(
                    occurrence_id=stable_id("oc", row["model"], row["video_id"], str(window.get("window_index", 0)),
                                            str(order)),
                    statement_id=statement.statement_id, video_id=row["video_id"],
                    window_index=int(window.get("window_index", 0)), evidence_order=order,
                    anomaly=int(window["anomaly"]), start_seconds=window.get("start_seconds"),
                    end_seconds=window.get("end_seconds"), parse_status=status, original_text=original))
    occurrences = sum(len(item.occurrences) for item in statements.values())
    quality = {"videos": len(videos),
               "videos_by_status": {status: sum(v["status"] == status for v in videos)
                                    for status in ("complete", "partial", "failed")},
               "windows_valid": windows_valid, "windows_invalid_or_failed": windows_invalid,
               "parse_status": parse_status, "occurrences": occurrences,
               "unique_statements": len(statements)}
    ordered = sorted(statements.values(), key=lambda item: (item.model, item.statement_id))
    return Corpus(ordered, videos, quality)


def load_corpus(videos_jsonl: Path) -> Corpus:
    return build_corpus(read_video_records(videos_jsonl))
