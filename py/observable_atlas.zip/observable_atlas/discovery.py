"""Etapas 2 a 5: corpus → embeddings → grupos → famílias → nomes → projeções.

Lê ``extraction/videos.jsonl`` e grava em ``discovery/``:

* ``taxonomy.json``: resultado completo (parâmetros, diagnóstico, famílias,
  grupos, frases, vídeos e projeções); é a fonte do atlas;
* ``statements.csv`` e ``clusters.csv``: tabelas para planilhas;
* ``hierarchy_candidates.csv``: todos os cortes avaliados na segunda etapa;
* ``embeddings.npz``: vetores das frases e centroides.

Quando os dados não permitem uma etapa (poucas frases, só ruído, poucos
grupos), o resultado registra isso em ``diagnostics`` em vez de forçar uma
taxonomia.
"""
from __future__ import annotations

import csv
from dataclasses import asdict
from datetime import datetime, timezone
from importlib.metadata import PackageNotFoundError, version
import json
from pathlib import Path
import sys
from typing import Callable

import numpy as np

from .clustering import FLAG_THRESHOLD, first_stage
from .composition import CATEGORIES, composition, load_reference_labels
from .config import DiscoveryConfig
from .corpus import Corpus, load_corpus
from .hierarchy import select_families
from .naming import ctfidf_topics, name_from
from .projection import project_3d

SCHEMA_VERSION = "2.0"


def _versions() -> dict:
    found = {"python": sys.version.split()[0]}
    for package in ("sentence-transformers", "hdbscan", "scikit-learn", "scipy", "numpy", "umap-learn", "torch"):
        try:
            found[package] = version(package)
        except PackageNotFoundError:
            found[package] = None
    return found


def _round(values) -> list[float]:
    return [round(float(value), 4) for value in values]


def discover(corpus: Corpus, config: DiscoveryConfig, output: Path,
             progress: Callable[[dict], None] | None = None) -> dict:
    config.validate()
    notify = (lambda step, **info: progress({"stage": "discovery", "step": step, **info})) if progress else (lambda *a, **k: None)
    diagnostics: list[dict] = []

    def warn(code: str, message: str, message_en: str, **extra):
        # message vai para a CLI e os relatórios; message_en para o atlas, cuja interface é em inglês.
        diagnostics.append({"code": code, "message": message, "message_en": message_en, **extra})

    if not corpus.statements:
        warn("no_evidence", "Nenhuma evidência válida foi extraída. Verifique as falhas em extraction/videos.jsonl.",
             "No valid evidence was extracted. See the failed videos in the Sources list.")
    reference = load_reference_labels(Path(config.reference_labels)) if config.reference_labels else None
    if reference is not None:
        known = {video["video_id"] for video in corpus.videos}
        missing = sorted(known - set(reference))
        if missing:
            warn("labels_missing", f"{len(missing)} vídeo(s) sem rótulo de referência; ficam fora da composição.",
                 f"{len(missing)} video(s) have no reference label and are left out of the composition.",
                 videos=missing[:20])

    notify("embedding", statements=len(corpus.statements))
    vectors, hdbscan_label, clusters = (first_stage(corpus, config.embedding_model, config.embedding_revision,
                                                    config.local_files_only, config.min_cluster_size,
                                                    config.min_samples) if corpus.statements else ({}, {}, []))
    for model in corpus.models:
        subset = corpus.by_model(model)
        found = [cluster for cluster in clusters if cluster.model == model]
        noise = sum(hdbscan_label[s.statement_id] == -1 for s in subset)
        if len(subset) < config.min_cluster_size:
            warn("too_few_statements", f"{model}: {len(subset)} frases únicas, menos que min_cluster_size="
                 f"{config.min_cluster_size}. Nenhum grupo pode ser formado.",
                 f"{model}: {len(subset)} unique statements, fewer than min_cluster_size={config.min_cluster_size}. "
                 "No cluster can be formed.", model=model)
        elif not found:
            warn("all_noise", f"{model}: o HDBSCAN não encontrou regiões densas; as {len(subset)} frases ficaram "
                 "como ruído. Use mais vídeos ou um min_cluster_size menor (registrado como desvio do artigo).",
                 f"{model}: HDBSCAN found no dense region; all {len(subset)} statements are noise. "
                 "More videos, or a smaller min_cluster_size, are needed.", model=model)
        elif noise / len(subset) > 0.6:
            warn("high_noise", f"{model}: {noise} de {len(subset)} frases ({noise / len(subset):.0%}) ficaram sem grupo.",
                 f"{model}: {noise} of {len(subset)} statements ({noise / len(subset):.0%}) are not in any cluster.",
                 model=model)

    statement_by_id = {s.statement_id: s for s in corpus.statements}
    excluded = {c.key for c in clusters if set(c.flags) & set(config.exclude_flags)}
    eligible = [c for c in clusters if c.key not in excluded]
    notify("hierarchy", clusters=len(eligible))
    hierarchy = select_families(np.array([c.centroid for c in eligible]), config.seed,
                                config.bootstrap_replicates, config.bootstrap_fraction) if eligible else None
    family_of: dict[str, int | None] = {c.key: None for c in clusters}
    if hierarchy is not None and hierarchy.status == "complete":
        for cluster, label in zip(eligible, hierarchy.labels):
            family_of[cluster.key] = label
    elif eligible:
        warn("hierarchy_not_estimated", "A segunda etapa não foi estimada: " + (hierarchy.reason or "") +
             ". Os grupos aparecem no atlas sem família.",
             f"The second grouping stage was not estimated ({hierarchy.reason_en}). Clusters are shown without a family.")

    # Famílias numeradas pela ordem do maior grupo, para que F01 seja estável e legível.
    members: dict[int, list] = {}
    for cluster in eligible:
        if family_of[cluster.key] is not None:
            members.setdefault(family_of[cluster.key], []).append(cluster)
    ordered = sorted(members.values(), key=lambda group: (-sum(len(c.statement_ids) for c in group),
                                                          min(c.key for c in group)))
    family_index = {c.key: number for number, group in enumerate(ordered, 1) for c in group}

    notify("naming")
    cluster_texts = {c.key: [statement_by_id[i].text for i in c.statement_ids] for c in clusters}
    cluster_topics = ctfidf_topics(cluster_texts) if clusters else {}
    family_texts = {str(n): [t for c in group for t in cluster_texts[c.key]] for n, group in enumerate(ordered, 1)}
    family_topics = ctfidf_topics(family_texts) if ordered else {}

    notify("projection")
    projections, projection_methods = {}, {}
    for offset, model in enumerate(corpus.models):
        subset = corpus.by_model(model)
        coords, method = project_3d(np.array([vectors[s.statement_id] for s in subset]), config.seed + offset)
        projection_methods[model] = method
        for statement, point in zip(subset, coords):
            projections[statement.statement_id] = _round(point)
    centroid_coords, centroid_method = project_3d(np.array([c.centroid for c in clusters]), config.seed)
    projection_methods["cluster_centroids"] = centroid_method

    cluster_rows = []
    for cluster, point in zip(clusters, centroid_coords):
        statements = [statement_by_id[i] for i in cluster.statement_ids]
        occurrences = [o for s in statements for o in s.occurrences]
        comp = composition(occurrences, reference)
        cluster_rows.append({
            "key": cluster.key, "model": cluster.model, "hdbscan_label": cluster.label,
            "family": family_index.get(cluster.key),
            "name": name_from(cluster_topics.get(cluster.key, []), statement_by_id[cluster.medoid_id].text),
            "topics": cluster_topics.get(cluster.key, []),
            "representative": statement_by_id[cluster.medoid_id].text, "statements": len(statements),
            "occurrences": len(occurrences), "videos": len({o.video_id for o in occurrences}),
            "composition": comp, "flags": cluster.flags, "flag_shares": cluster.flag_shares,
            "excluded_from_hierarchy": cluster.key in excluded, "centroid_xyz": _round(point),
            "statement_ids": cluster.statement_ids})
    family_rows = []
    for number, group in enumerate(ordered, 1):
        keys = [c.key for c in group]
        rows = [row for row in cluster_rows if row["key"] in keys]
        occurrences = [o for c in group for i in c.statement_ids for o in statement_by_id[i].occurrences]
        largest = max(rows, key=lambda row: (row["statements"], row["key"]))
        family_rows.append({
            "id": number, "code": f"F{number:02d}",
            "name": name_from(family_topics.get(str(number), []), largest["name"]),
            "topics": family_topics.get(str(number), []), "representative_cluster": largest["key"],
            "representative": largest["representative"], "clusters": keys,
            "statements": sum(row["statements"] for row in rows), "composition": composition(occurrences, reference),
            "models": sorted({row["model"] for row in rows})})

    cluster_of = {i: c.key for c in clusters for i in c.statement_ids}
    statement_rows = [{
        "id": s.statement_id, "model": s.model, "text": s.text, "cluster": cluster_of.get(s.statement_id),
        "family": family_index.get(cluster_of.get(s.statement_id)), "xyz": projections.get(s.statement_id),
        "occurrences": [asdict(o) for o in s.occurrences]} for s in corpus.statements]

    status = "complete" if family_rows else ("clusters_only" if clusters else "no_clusters")
    result = {
        "schema_version": SCHEMA_VERSION, "status": status,
        "created_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "composition_source": "reference" if reference is not None else "prediction",
        "categories": CATEGORIES,
        "parameters": {"embedding_model": config.embedding_model, "embedding_revision": config.embedding_revision,
                       "hdbscan": {"metric": "euclidean", "min_cluster_size": config.min_cluster_size,
                                   "min_samples": config.min_samples, "cluster_selection_method": "eom"},
                       "deduplication": "exact normalized text, per VLM",
                       "flags": {"threshold": FLAG_THRESHOLD, "excluded": config.exclude_flags},
                       "hierarchy": hierarchy.settings if hierarchy else None,
                       "projection": projection_methods},
        "hierarchy": {"status": hierarchy.status if hierarchy else "not_estimated",
                      "selected": hierarchy.selected if hierarchy else None,
                      "reason": hierarchy.reason if hierarchy else "nenhum grupo disponível",
                      "candidates_evaluated": len(hierarchy.candidates) if hierarchy else 0},
        "counts": {"videos": len(corpus.videos), "statements": len(corpus.statements),
                   "occurrences": corpus.quality["occurrences"], "clusters": len(clusters),
                   "noise_statements": sum(1 for s in corpus.statements if s.statement_id not in cluster_of),
                   "families": len(family_rows), "excluded_clusters": len(excluded)},
        "corpus_quality": corpus.quality, "diagnostics": diagnostics, "software": _versions(),
        "models": corpus.models, "families": family_rows, "clusters": cluster_rows,
        "statements": statement_rows, "videos": corpus.videos}
    _write(output, result, hierarchy, vectors, clusters)
    return result


def _write(output: Path, result: dict, hierarchy, vectors: dict, clusters: list) -> None:
    output.mkdir(parents=True, exist_ok=True)
    (output / "taxonomy.json").write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
    with (output / "statements.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["statement_id", "model", "text", "cluster", "family", "occurrences", "videos"])
        for row in result["statements"]:
            writer.writerow([row["id"], row["model"], row["text"], row["cluster"] or "",
                             f"F{row['family']:02d}" if row["family"] else "", len(row["occurrences"]),
                             ";".join(sorted({o["video_id"] for o in row["occurrences"]}))])
    with (output / "clusters.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["cluster", "model", "family", "name", "representative", "statements", "videos",
                         "anomalous_share", "category", "flags"])
        for row in result["clusters"]:
            writer.writerow([row["key"], row["model"], f"F{row['family']:02d}" if row["family"] else "", row["name"],
                             row["representative"], row["statements"], row["videos"],
                             row["composition"]["share"], row["composition"]["category"], ";".join(row["flags"])])
    if hierarchy is not None and hierarchy.candidates:
        with (output / "hierarchy_candidates.csv").open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(hierarchy.candidates[0]))
            writer.writeheader()
            writer.writerows(hierarchy.candidates)
    ids = sorted(vectors)
    dim = len(next(iter(vectors.values()))) if vectors else 0
    np.savez_compressed(output / "embeddings.npz", statement_ids=np.array(ids, dtype=str),
                        statement_vectors=np.array([vectors[i] for i in ids], dtype=np.float32).reshape(len(ids), dim),
                        cluster_keys=np.array([c.key for c in clusters], dtype=str),
                        cluster_centroids=np.array([c.centroid for c in clusters], dtype=np.float32).reshape(len(clusters), dim))


def discover_run(run_dir: Path, config: DiscoveryConfig, progress=None) -> dict:
    source = run_dir / "extraction" / "videos.jsonl"
    if not source.exists():
        raise FileNotFoundError(f"{source} não existe. Execute a extração antes da descoberta.")
    return discover(load_corpus(source), config, run_dir / "discovery", progress)
