"""Etapa 4: segundo agrupamento (centroides → famílias).

Implementa a seção 3.5 do artigo. Cada grupo do HDBSCAN é representado pela
média L2-normalizada dos embeddings das suas frases; os centroides de todas as
VLMs entram juntos. Avaliamos ligação média e completa com distância cosseno
em todos os cortes k = 2 … n−1, descartamos cortes com grupos unitários e
pontuamos cada par (ligação, k) com critérios normalizados por posto:

    S = 0,30·silhueta + 0,35·estabilidade + 0,20·concordância + 0,10·coesão + 0,05·Ins

Escolhemos o menor k com S ≥ 0,95·max(S).

Detalhe que o artigo não especifica: a reamostragem bootstrap. Usamos 50
reamostragens sem reposição de 80% dos centroides, com semente fixa, e medimos
o ARI entre a partição da amostra e a partição completa restrita à amostra.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
import warnings

import numpy as np

WEIGHTS = {"silhouette": 0.30, "bootstrap_stability": 0.35, "linkage_agreement": 0.20,
           "cohesion": 0.10, "singleton_free": 0.05}
METHODS = ("average", "complete")


@dataclass
class HierarchyResult:
    status: str
    labels: list[int]
    selected: dict | None = None
    candidates: list[dict] = field(default_factory=list)
    reason: str | None = None
    reason_en: str | None = None
    settings: dict = field(default_factory=dict)


def _cohesion(vectors: np.ndarray, labels: np.ndarray) -> float:
    distances = []
    for group in np.unique(labels):
        members = vectors[labels == group]
        if len(members) > 1:
            similarity = members @ members.T
            distances.extend((1.0 - similarity[np.triu_indices(len(members), 1)]).tolist())
    # Inverso da distância média intragrupo. Só a ordem importa (critério por posto).
    return 1.0 / max(float(np.mean(distances)), 1e-9) if distances else 0.0


def select_families(centroids: np.ndarray, seed: int = 2027, replicates: int = 50,
                    fraction: float = 0.8) -> HierarchyResult:
    from scipy.cluster.hierarchy import fcluster, linkage
    from scipy.stats import rankdata
    from sklearn.metrics import adjusted_rand_score, silhouette_score

    n = len(centroids)
    settings = {"methods": list(METHODS), "metric": "cosine", "k_range": [2, max(n - 1, 2)],
                "weights": WEIGHTS, "bootstrap_replicates": replicates, "bootstrap_fraction": fraction,
                "seed": seed, "rule": "smallest k with S >= 0.95 * max(S); cuts with singleton groups excluded"}
    if n < 4:
        return HierarchyResult("not_estimated", list(range(n)), settings=settings,
                               reason=f"são necessários ao menos 4 grupos para um corte sem grupos unitários; há {n}",
                               reason_en=f"at least 4 clusters are needed for a cut without singleton groups; found {n}")
    centroids = np.asarray(centroids, dtype=np.float64)
    trees = {method: linkage(centroids, method=method, metric="cosine") for method in METHODS}
    ks = range(2, n)
    partitions = {method: {k: fcluster(trees[method], k, criterion="maxclust") for k in ks} for method in METHODS}
    # sklearn avisa quando há muitos rótulos por amostra (k alto); é esperado aqui.
    warnings.filterwarnings("ignore", message="The number of unique classes", category=UserWarning)
    rng = np.random.default_rng(seed)
    size = max(3, min(n - 1, math.ceil(fraction * n)))
    stability = {method: {k: [] for k in ks} for method in METHODS}
    for _ in range(replicates):
        sample = np.sort(rng.choice(n, size=size, replace=False))
        for method in METHODS:
            tree = linkage(centroids[sample], method=method, metric="cosine")
            for k in ks:
                if k >= size:
                    continue
                boot = fcluster(tree, k, criterion="maxclust")
                stability[method][k].append(adjusted_rand_score(partitions[method][k][sample], boot))

    candidates = []
    for method in METHODS:
        for k in ks:
            labels = partitions[method][k]
            _, counts = np.unique(labels, return_counts=True)
            if len(counts) < 2 or counts.min() < 2 or not stability[method][k]:
                continue
            candidates.append({"method": method, "k": k, "labels": labels,
                               "silhouette": float(silhouette_score(centroids, labels, metric="cosine")),
                               "bootstrap_stability": float(np.mean(stability[method][k])),
                               "linkage_agreement": float(adjusted_rand_score(partitions["average"][k],
                                                                              partitions["complete"][k])),
                               "cohesion": _cohesion(centroids, labels), "singleton_free": 1.0})
    if not candidates:
        return HierarchyResult("not_estimated", list(range(n)), settings=settings,
                               reason="nenhum corte sem grupos unitários foi encontrado",
                               reason_en="no cut without singleton groups was found")
    for criterion in WEIGHTS:
        ranks = rankdata([row[criterion] for row in candidates], method="average") / len(candidates)
        for row, rank in zip(candidates, ranks):
            row[criterion + "_rank"] = float(rank)
    for row in candidates:
        row["score"] = sum(weight * row[name + "_rank"] for name, weight in WEIGHTS.items())
    best = max(row["score"] for row in candidates)
    selected = min((row for row in candidates if row["score"] >= 0.95 * best),
                   key=lambda row: (row["k"], -row["score"], row["method"]))
    summary = [{key: (round(value, 6) if isinstance(value, float) else value)
                for key, value in row.items() if key != "labels"} for row in candidates]
    chosen = {key: value for key, value in summary[candidates.index(selected)].items()}
    return HierarchyResult("complete", [int(value) - 1 for value in selected["labels"]], selected=chosen,
                           candidates=summary, settings=settings)
