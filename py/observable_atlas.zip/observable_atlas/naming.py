"""Etapa 5: nomes automáticos a partir das evidências.

Cada grupo e cada família recebem:

* ``topics``: até três termos com maior c-TF-IDF (TF-IDF por classe), extraídos
  apenas das frases do próprio grupo e presentes em pelo menos
  ``MIN_SUPPORT`` dessas frases;
* ``name``: os tópicos unidos por " · ";
* ``representative``: a frase real mais próxima do centroide (medoide).

Nenhum texto é gerado: os termos e a frase representativa vêm literalmente das
evidências. Plurais simples são reduzidos ao singular para não dividir a
contagem ("cars"/"car").
"""
from __future__ import annotations

import math
import re
from collections import Counter

MIN_SUPPORT = 0.25
MAX_TOPICS = 3
# Palavras que descrevem o meio (vídeo, frame) e não o conteúdo observado.
MEDIUM_WORDS = {"video", "frame", "footage", "image", "show", "showing", "shows", "visible", "appear",
                "appears", "seen", "seem", "seems", "depict", "depicts", "sequence", "clip", "does", "doe"}
_TOKEN = re.compile(r"[a-z][a-z'-]*[a-z]|[a-z]")


def _stop_words() -> frozenset[str]:
    from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
    return frozenset(ENGLISH_STOP_WORDS) | MEDIUM_WORDS


# Palavras terminadas em "s" que não são plurais simples (ou cujo singular ingênuo é errado).
NOT_PLURAL = {"does", "goes", "gas", "bus", "news", "series", "species", "clothes", "pants", "jeans", "shorts",
              "glasses", "stairs", "always", "perhaps", "towards", "across", "various", "previous", "nearby"}


def singular(word: str) -> str:
    if word in NOT_PLURAL:
        return word
    if len(word) > 4 and word.endswith("ies"):
        return word[:-3] + "y"
    if len(word) > 4 and word.endswith(("ches", "shes", "sses", "xes")):
        return word[:-2]
    if len(word) > 3 and word.endswith("s") and not word.endswith(("ss", "us", "is", "ous")):
        return word[:-1]
    return word


def terms_of(text: str, stop: frozenset[str]) -> set[str]:
    """Unigramas e bigramas (sem stop words) de uma frase."""
    tokens = [singular(token) for token in _TOKEN.findall(text.lower())]
    tokens = [token for token in tokens if token not in stop and len(token) > 1]
    return set(tokens) | {f"{a} {b}" for a, b in zip(tokens, tokens[1:])}


def ctfidf_topics(groups: dict[str, list[str]]) -> dict[str, list[dict]]:
    """``groups``: id → frases. Devolve id → [{term, score, support}], já filtrado e ordenado."""
    stop = _stop_words()
    term_sets = {gid: [terms_of(text, stop) for text in texts] for gid, texts in groups.items()}
    frequencies = {gid: Counter(term for terms in sets for term in terms) for gid, sets in term_sets.items()}
    total = Counter()
    for counts in frequencies.values():
        total.update(counts)
    average = sum(sum(counts.values()) for counts in frequencies.values()) / max(len(frequencies), 1)
    result = {}
    for gid, counts in frequencies.items():
        size = max(sum(counts.values()), 1)
        documents = max(len(term_sets[gid]), 1)
        ranked = []
        for term, count in counts.items():
            support = sum(term in terms for terms in term_sets[gid]) / documents
            if support < MIN_SUPPORT and not (documents < 4 and count >= 2):
                continue
            score = (count / size) * math.log(1 + average / total[term])
            # Bigramas recebem leve preferência quando tão frequentes quanto o unigrama.
            ranked.append({"term": term, "score": round(score * (1.15 if " " in term else 1), 6),
                           "support": round(support, 3)})
        ranked.sort(key=lambda row: (-row["score"], -row["support"], row["term"]))
        chosen: list[dict] = []
        for row in ranked:
            words = set(row["term"].split())
            if any(words & set(other["term"].split()) for other in chosen):
                continue
            chosen.append(row)
            if len(chosen) == MAX_TOPICS:
                break
        result[gid] = chosen
    return result


def name_from(topics: list[dict], fallback: str) -> str:
    return " · ".join(row["term"] for row in topics) if topics else fallback
