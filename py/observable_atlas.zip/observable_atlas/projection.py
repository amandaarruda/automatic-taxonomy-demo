"""Projeções 3D para o atlas.

UMAP (cosseno, semente fixa) serve apenas à visualização, como no artigo: a
posição dos pontos não entra em nenhum agrupamento. Com poucos pontos o UMAP
não é definido; usamos PCA e registramos o método.
"""
from __future__ import annotations

import os
from pathlib import Path
import tempfile
import warnings

import numpy as np


def project_3d(vectors: np.ndarray, seed: int) -> tuple[np.ndarray, str]:
    vectors = np.asarray(vectors, dtype=np.float32)
    n = len(vectors)
    if n == 0:
        return np.zeros((0, 3)), "empty"
    if n == 1:
        return np.zeros((1, 3)), "single point"
    if n >= 10:
        cache = Path(tempfile.gettempdir()) / "observable-atlas-numba"
        cache.mkdir(exist_ok=True)
        os.environ.setdefault("NUMBA_CACHE_DIR", str(cache))
        try:
            import umap
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                coords = umap.UMAP(n_components=3, n_neighbors=min(15, n - 1), min_dist=0.1, metric="cosine",
                                   random_state=seed, transform_seed=seed, n_jobs=1).fit_transform(vectors)
            return np.asarray(coords, dtype=np.float64), f"UMAP 3D (cosine, n_neighbors={min(15, n - 1)}, seed {seed})"
        except Exception as exc:  # o atlas continua utilizável com PCA
            fallback = f"PCA 3D (UMAP failed: {type(exc).__name__})"
    else:
        fallback = "PCA 3D (fewer than 10 points)"
    centered = vectors - vectors.mean(axis=0)
    u, s, _ = np.linalg.svd(centered, full_matrices=False)
    coords = u[:, :3] * s[:3]
    if coords.shape[1] < 3:
        coords = np.column_stack([coords, np.zeros((n, 3 - coords.shape[1]))])
    return coords.astype(np.float64), fallback
