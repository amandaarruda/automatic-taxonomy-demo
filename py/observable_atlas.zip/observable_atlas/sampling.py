"""Amostragem de frames.

Dois modos:

* ``uniform16``: 16 frames distribuídos linearmente do primeiro ao último
  frame, como na pesquisa. Vídeos com menos de 16 frames usam todos os frames,
  sem repetição.
* ``1fps``: um frame por segundo de vídeo. As amostras são agrupadas em janelas
  consecutivas de até ``window_size`` frames; cada janela é uma chamada à VLM.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import math
from pathlib import Path

SAMPLING_MODES = ("uniform16", "1fps")
VIDEO_EXTENSIONS = {".mp4", ".m4v", ".mov", ".mkv", ".avi", ".webm", ".mpg", ".mpeg"}


@dataclass
class Frame:
    ordinal: int
    frame_index: int
    seconds: float
    path: Path
    sha256: str


@dataclass
class VideoSample:
    fps: float
    frame_count: int
    width: int
    height: int
    frames: list[Frame] = field(default_factory=list)

    @property
    def duration_seconds(self) -> float:
        return self.frame_count / self.fps


@dataclass
class Window:
    index: int
    frames: list[Frame]

    @property
    def start_seconds(self) -> float:
        return self.frames[0].seconds

    @property
    def end_seconds(self) -> float:
        return self.frames[-1].seconds

    def describe(self) -> dict:
        return {"window_index": self.index,
                "start_seconds": round(self.start_seconds, 3),
                "end_seconds": round(self.end_seconds, 3),
                "frame_indices": [frame.frame_index for frame in self.frames],
                "frame_sha256": [frame.sha256 for frame in self.frames]}


def frame_indices(frame_count: int, fps: float, mode: str) -> list[int]:
    if frame_count < 1 or not math.isfinite(fps) or fps <= 0:
        raise ValueError("o vídeo não informa quantidade de frames e taxa de frames válidas")
    if mode == "uniform16":
        n = min(frame_count, 16)
        if n == 1:
            return [0]
        return [round(i * (frame_count - 1) / (n - 1)) for i in range(n)]
    if mode == "1fps":
        seconds = math.ceil(frame_count / fps)
        return sorted({min(int(round(t * fps)), frame_count - 1) for t in range(seconds)})
    raise ValueError(f"amostragem desconhecida: {mode!r}; use uniform16 ou 1fps")


def parse_frame_size(value: str | None) -> tuple[int, int] | None:
    """``"448x448"`` → (448, 448); ``"native"``/``None`` → sem redimensionar."""
    if value in (None, "", "native"):
        return None
    try:
        width, height = (int(part) for part in str(value).lower().split("x"))
    except ValueError as exc:
        raise ValueError("frame_size deve ser 'native' ou LARGURAxALTURA, por exemplo 448x448") from exc
    if not (16 <= width <= 4096 and 16 <= height <= 4096):
        raise ValueError("frame_size deve ficar entre 16 e 4096 pixels por lado")
    return width, height


def extract_frames(video: Path, destination: Path, mode: str,
                   frame_size: tuple[int, int] | None = (448, 448), jpeg_quality: int = 95) -> VideoSample:
    import cv2

    capture = cv2.VideoCapture(str(video))
    if not capture.isOpened():
        raise ValueError(f"não foi possível abrir o vídeo (formato ou codec não suportado): {video.name}")
    try:
        count = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = float(capture.get(cv2.CAP_PROP_FPS))
        width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
        sample = VideoSample(fps=fps, frame_count=count, width=width, height=height)
        destination.mkdir(parents=True, exist_ok=True)
        for ordinal, index in enumerate(frame_indices(count, fps, mode)):
            if not capture.set(cv2.CAP_PROP_POS_FRAMES, index):
                raise ValueError(f"não foi possível posicionar o vídeo no frame {index}")
            ok, image = capture.read()
            if not ok:
                raise ValueError(f"não foi possível decodificar o frame {index} de {video.name}")
            if frame_size is not None:
                image = cv2.resize(image, frame_size, interpolation=cv2.INTER_AREA)
            path = destination / f"{ordinal:06d}.jpg"
            if not cv2.imwrite(str(path), image, [cv2.IMWRITE_JPEG_QUALITY, jpeg_quality]):
                raise OSError(f"não foi possível gravar {path}")
            sample.frames.append(Frame(ordinal, index, index / fps, path,
                                       hashlib.sha256(path.read_bytes()).hexdigest()))
        return sample
    finally:
        capture.release()


def make_windows(frames: list[Frame], window_size: int) -> list[Window]:
    if window_size < 1:
        raise ValueError("window_size deve ser positivo")
    return [Window(i, frames[start:start + window_size])
            for i, start in enumerate(range(0, len(frames), window_size))]


def find_videos(inputs: list[Path]) -> list[Path]:
    """Expande diretórios (recursivamente) e mantém a ordem determinística."""
    found: list[Path] = []
    for item in inputs:
        if item.is_dir():
            found.extend(sorted(path for path in item.rglob("*")
                                if path.is_file() and path.suffix.lower() in VIDEO_EXTENSIONS))
        elif item.is_file():
            found.append(item)
        else:
            raise FileNotFoundError(f"vídeo ou pasta não encontrado: {item}")
    unique, seen = [], set()
    for path in found:
        key = path.resolve()
        if key not in seen:
            seen.add(key)
            unique.append(path)
    return unique
